laser_proc
==========

Converts representations of sensor_msgs/LaserScan and sensor_msgs/MultiEchoLaserScan